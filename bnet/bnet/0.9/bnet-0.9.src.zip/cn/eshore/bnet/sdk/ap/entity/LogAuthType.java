/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class LogAuthType
/*     */ {
/*     */   protected String appSystemId;
/*     */   protected String bnetAccount;
/*     */   protected String userAccount;
/*     */   protected String password;
/*     */   protected String timeStamp;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getAppSystemId()
/*     */   {
/*  24 */     return this.appSystemId;
/*     */   }
/*     */ 
/*     */   public void setAppSystemId(String value)
/*     */   {
/*  36 */     this.appSystemId = value;
/*     */   }
/*     */ 
/*     */   public String getBnetAccount()
/*     */   {
/*  48 */     return this.bnetAccount;
/*     */   }
/*     */ 
/*     */   public void setBnetAccount(String value)
/*     */   {
/*  60 */     this.bnetAccount = value;
/*     */   }
/*     */ 
/*     */   public String getUserAccount()
/*     */   {
/*  72 */     return this.userAccount;
/*     */   }
/*     */ 
/*     */   public void setUserAccount(String value)
/*     */   {
/*  84 */     this.userAccount = value;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/*  96 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setPassword(String value)
/*     */   {
/* 108 */     this.password = value;
/*     */   }
/*     */ 
/*     */   public String getTimeStamp()
/*     */   {
/* 120 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */   public void setTimeStamp(String value)
/*     */   {
/* 132 */     this.timeStamp = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 144 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 156 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.LogAuthType
 * JD-Core Version:    0.6.0
 */