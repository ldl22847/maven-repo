/*    */ package cn.eshore.bnet.sdk.ap.exception;
/*    */ 
/*    */ public class HashCodeException extends Exception
/*    */ {
/*    */   public HashCodeException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public HashCodeException(String message, Throwable cause)
/*    */   {
/* 16 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public HashCodeException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ 
/*    */   public HashCodeException(Throwable cause)
/*    */   {
/* 26 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.exception.HashCodeException
 * JD-Core Version:    0.6.0
 */