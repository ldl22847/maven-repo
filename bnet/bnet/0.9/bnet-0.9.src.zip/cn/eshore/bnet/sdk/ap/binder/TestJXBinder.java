/*    */ package cn.eshore.bnet.sdk.ap.binder;
/*    */ 
/*    */ import cn.eshore.bnet.sdk.ap.component.JXBinder;
/*    */ import cn.eshore.bnet.sdk.ap.entity.OperPublicInfoType;
/*    */ import cn.eshore.bnet.sdk.ap.entity.ResponseType;
/*    */ import cn.eshore.bnet.sdk.ap.entity.ReturnType;
/*    */ import cn.eshore.bnet.sdk.ap.exception.ConvertJavaToXmlException;
/*    */ import cn.eshore.bnet.sdk.ap.exception.ConvertXmlToJavaException;
/*    */ import cn.eshore.bnet.sdk.ap.exception.FetchXmlFromBnetException;
/*    */ import java.io.PrintStream;
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ public class TestJXBinder extends TestCase
/*    */ {
/*    */   protected void setUp()
/*    */     throws Exception
/*    */   {
/* 19 */     super.setUp();
/*    */   }
/*    */ 
/*    */   protected void tearDown() throws Exception {
/* 23 */     super.tearDown();
/*    */   }
/*    */ 
/*    */   public void testBindXml2Java() throws ConvertXmlToJavaException, FetchXmlFromBnetException {
/* 27 */     ResponseType response = (ResponseType)
/* 28 */       JXBinder.bindXml2Java(
/* 29 */       "http://10.18.96.44:7801/ap/v4/BnetForApProxy", 
/* 30 */       "servName=gdbnet.queryOper&operId=20100301175616161&appSystemId=GD9900083&timeStamp=2010-03-15 08:00:00&hashcode=AC31DCAFB2FFAD76B7F32B1E4B45B4C2");
/*    */ 
/* 32 */     System.out.println(response.getOperPublicInfo().getResult());
/*    */   }
/*    */ 
/*    */   public void testBindJava2Xml() throws ConvertJavaToXmlException {
/* 36 */     ReturnType returnInfo = new ReturnType();
/* 37 */     returnInfo.setOperId("111111111111");
/* 38 */     returnInfo.setResult("20000");
/* 39 */     returnInfo.setResultMessage("success");
/* 40 */     returnInfo.setHashcode("45190F0FA16AB70B48BA8FE039ABDF6A");
/*    */ 
/* 42 */     System.out.println(JXBinder.bindJava2Xml(returnInfo));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.binder.TestJXBinder
 * JD-Core Version:    0.6.0
 */