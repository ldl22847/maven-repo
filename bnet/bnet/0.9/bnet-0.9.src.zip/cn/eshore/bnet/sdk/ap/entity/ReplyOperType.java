/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class ReplyOperType
/*     */ {
/*     */   protected String operId;
/*     */   protected String appSystemId;
/*     */   protected String result;
/*     */   protected String resultMessage;
/*     */   protected String timeStamp;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getOperId()
/*     */   {
/*  23 */     return this.operId;
/*     */   }
/*     */ 
/*     */   public void setOperId(String value)
/*     */   {
/*  35 */     this.operId = value;
/*     */   }
/*     */ 
/*     */   public String getAppSystemId()
/*     */   {
/*  47 */     return this.appSystemId;
/*     */   }
/*     */ 
/*     */   public void setAppSystemId(String value)
/*     */   {
/*  59 */     this.appSystemId = value;
/*     */   }
/*     */ 
/*     */   public String getResult()
/*     */   {
/*  71 */     return this.result;
/*     */   }
/*     */ 
/*     */   public void setResult(String value)
/*     */   {
/*  83 */     this.result = value;
/*     */   }
/*     */ 
/*     */   public String getResultMessage()
/*     */   {
/*  95 */     return this.resultMessage;
/*     */   }
/*     */ 
/*     */   public void setResultMessage(String value)
/*     */   {
/* 107 */     this.resultMessage = value;
/*     */   }
/*     */ 
/*     */   public String getTimeStamp()
/*     */   {
/* 119 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */   public void setTimeStamp(String value)
/*     */   {
/* 131 */     this.timeStamp = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 143 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 155 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.ReplyOperType
 * JD-Core Version:    0.6.0
 */