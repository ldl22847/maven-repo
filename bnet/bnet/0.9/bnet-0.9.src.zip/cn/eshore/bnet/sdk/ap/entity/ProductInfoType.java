/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ProductInfoType
/*     */ {
/*     */   protected String productId;
/*     */   protected String productSpecId;
/*     */   protected String productState;
/*     */   protected String parentProductId;
/*     */   protected List productAttribute;
/*     */ 
/*     */   public String getProductId()
/*     */   {
/*  25 */     return this.productId;
/*     */   }
/*     */ 
/*     */   public void setProductId(String value)
/*     */   {
/*  37 */     this.productId = value;
/*     */   }
/*     */ 
/*     */   public String getProductSpecId()
/*     */   {
/*  49 */     return this.productSpecId;
/*     */   }
/*     */ 
/*     */   public void setProductSpecId(String value)
/*     */   {
/*  61 */     this.productSpecId = value;
/*     */   }
/*     */ 
/*     */   public String getProductState()
/*     */   {
/*  73 */     return this.productState;
/*     */   }
/*     */ 
/*     */   public void setProductState(String value)
/*     */   {
/*  85 */     this.productState = value;
/*     */   }
/*     */ 
/*     */   public String getParentProductId() {
/*  89 */     return this.parentProductId;
/*     */   }
/*     */ 
/*     */   public void setParentProductId(String parentProductId) {
/*  93 */     this.parentProductId = parentProductId;
/*     */   }
/*     */ 
/*     */   public List getProductAttribute()
/*     */   {
/* 119 */     if (this.productAttribute == null) {
/* 120 */       this.productAttribute = new ArrayList();
/*     */     }
/* 122 */     return this.productAttribute;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.ProductInfoType
 * JD-Core Version:    0.6.0
 */