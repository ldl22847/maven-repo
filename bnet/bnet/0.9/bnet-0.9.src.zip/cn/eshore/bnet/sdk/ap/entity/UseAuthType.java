/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class UseAuthType
/*     */ {
/*     */   protected String appSystemId;
/*     */   protected String userAccountId;
/*     */   protected String productId;
/*     */   protected String useSessionId;
/*     */   protected String useValue;
/*     */   protected String chargingType;
/*     */   protected String timeStamp;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getAppSystemId()
/*     */   {
/*  26 */     return this.appSystemId;
/*     */   }
/*     */ 
/*     */   public void setAppSystemId(String value)
/*     */   {
/*  38 */     this.appSystemId = value;
/*     */   }
/*     */ 
/*     */   public String getUserAccountId()
/*     */   {
/*  50 */     return this.userAccountId;
/*     */   }
/*     */ 
/*     */   public void setUserAccountId(String value)
/*     */   {
/*  62 */     this.userAccountId = value;
/*     */   }
/*     */ 
/*     */   public String getProductId()
/*     */   {
/*  74 */     return this.productId;
/*     */   }
/*     */ 
/*     */   public void setProductId(String value)
/*     */   {
/*  86 */     this.productId = value;
/*     */   }
/*     */ 
/*     */   public String getUseSessionId()
/*     */   {
/*  98 */     return this.useSessionId;
/*     */   }
/*     */ 
/*     */   public void setUseSessionId(String value)
/*     */   {
/* 110 */     this.useSessionId = value;
/*     */   }
/*     */ 
/*     */   public String getUseValue()
/*     */   {
/* 115 */     return this.useValue;
/*     */   }
/*     */ 
/*     */   public void setUseValue(String useValue) {
/* 119 */     this.useValue = useValue;
/*     */   }
/*     */ 
/*     */   public String getChargingType() {
/* 123 */     return this.chargingType;
/*     */   }
/*     */ 
/*     */   public void setChargingType(String chargingType) {
/* 127 */     this.chargingType = chargingType;
/*     */   }
/*     */ 
/*     */   public String getTimeStamp()
/*     */   {
/* 139 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */   public void setTimeStamp(String value)
/*     */   {
/* 151 */     this.timeStamp = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 163 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 175 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.UseAuthType
 * JD-Core Version:    0.6.0
 */