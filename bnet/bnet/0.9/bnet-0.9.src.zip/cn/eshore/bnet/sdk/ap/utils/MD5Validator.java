/*    */ package cn.eshore.bnet.sdk.ap.utils;
/*    */ 
/*    */ public class MD5Validator
/*    */ {
/*    */   public static boolean validate(String[] strs, String hashcode)
/*    */   {
/* 11 */     if (Utils.isNullOrEmptyArray(strs)) {
/* 12 */       return MD5Crypter.MD5Encode("").equals(hashcode);
/*    */     }
/*    */ 
/* 15 */     StringBuffer sb = new StringBuffer();
/* 16 */     for (int i = 0; i < strs.length; i++) {
/* 17 */       sb.append(strs[i]);
/*    */     }
/*    */ 
/* 20 */     return MD5Crypter.MD5Encode(sb.toString()).equals(hashcode);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.utils.MD5Validator
 * JD-Core Version:    0.6.0
 */