/*    */ package cn.eshore.bnet.sdk.ap.entity;
/*    */ 
/*    */ public class UserAccountInfoType
/*    */ {
/*    */   protected String userAccountId;
/*    */   protected String userAccount;
/*    */   protected String userType;
/*    */ 
/*    */   public String getUserAccountId()
/*    */   {
/* 21 */     return this.userAccountId;
/*    */   }
/*    */ 
/*    */   public void setUserAccountId(String value)
/*    */   {
/* 33 */     this.userAccountId = value;
/*    */   }
/*    */ 
/*    */   public String getUserAccount()
/*    */   {
/* 45 */     return this.userAccount;
/*    */   }
/*    */ 
/*    */   public void setUserAccount(String value)
/*    */   {
/* 57 */     this.userAccount = value;
/*    */   }
/*    */ 
/*    */   public String getUserType()
/*    */   {
/* 62 */     return this.userType;
/*    */   }
/*    */ 
/*    */   public void setUserType(String userType) {
/* 66 */     this.userType = userType;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.UserAccountInfoType
 * JD-Core Version:    0.6.0
 */