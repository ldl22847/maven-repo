/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class BnetAccountExInfoType
/*     */ {
/*     */   protected String bnetId;
/*     */   protected String contactName;
/*     */   protected String contactPhone;
/*     */   protected String contactAddress;
/*     */ 
/*     */   public String getBnetId()
/*     */   {
/*  22 */     return this.bnetId;
/*     */   }
/*     */ 
/*     */   public void setBnetId(String value)
/*     */   {
/*  34 */     this.bnetId = value;
/*     */   }
/*     */ 
/*     */   public String getContactName()
/*     */   {
/*  46 */     return this.contactName;
/*     */   }
/*     */ 
/*     */   public void setContactName(String value)
/*     */   {
/*  58 */     this.contactName = value;
/*     */   }
/*     */ 
/*     */   public String getContactPhone()
/*     */   {
/*  70 */     return this.contactPhone;
/*     */   }
/*     */ 
/*     */   public void setContactPhone(String value)
/*     */   {
/*  82 */     this.contactPhone = value;
/*     */   }
/*     */ 
/*     */   public String getContactAddress()
/*     */   {
/*  94 */     return this.contactAddress;
/*     */   }
/*     */ 
/*     */   public void setContactAddress(String value)
/*     */   {
/* 106 */     this.contactAddress = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.BnetAccountExInfoType
 * JD-Core Version:    0.6.0
 */