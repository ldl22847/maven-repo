/*    */ package cn.eshore.bnet.sdk.ap.entity;
/*    */ 
/*    */ public class ReturnType
/*    */ {
/*    */   protected String operId;
/*    */   protected String result;
/*    */   protected String resultMessage;
/*    */   protected String hashcode;
/*    */ 
/*    */   public String getOperId()
/*    */   {
/* 17 */     return this.operId;
/*    */   }
/*    */ 
/*    */   public void setOperId(String value)
/*    */   {
/* 28 */     this.operId = value;
/*    */   }
/*    */ 
/*    */   public String getResult()
/*    */   {
/* 36 */     return this.result;
/*    */   }
/*    */ 
/*    */   public void setResult(String value)
/*    */   {
/* 44 */     this.result = value;
/*    */   }
/*    */ 
/*    */   public String getResultMessage()
/*    */   {
/* 54 */     return this.resultMessage;
/*    */   }
/*    */ 
/*    */   public void setResultMessage(String value)
/*    */   {
/* 65 */     this.resultMessage = value;
/*    */   }
/*    */ 
/*    */   public String getHashcode()
/*    */   {
/* 75 */     return this.hashcode;
/*    */   }
/*    */ 
/*    */   public void setHashcode(String value)
/*    */   {
/* 86 */     this.hashcode = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.ReturnType
 * JD-Core Version:    0.6.0
 */