/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class BizPublicInfoType
/*     */ {
/*     */   protected String useSessionId;
/*     */   protected String preUseValue;
/*     */   protected String remainderValue;
/*     */   protected String preConsumeTime;
/*     */   protected String result;
/*     */   protected String resultMessage;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getUseSessionId()
/*     */   {
/*  24 */     return this.useSessionId;
/*     */   }
/*     */ 
/*     */   public void setUseSessionId(String value)
/*     */   {
/*  36 */     this.useSessionId = value;
/*     */   }
/*     */ 
/*     */   public String getPreUseValue()
/*     */   {
/*  48 */     return this.preUseValue;
/*     */   }
/*     */ 
/*     */   public void setPreUseValue(String value)
/*     */   {
/*  60 */     this.preUseValue = value;
/*     */   }
/*     */ 
/*     */   public String getRemainderValue()
/*     */   {
/*  72 */     return this.remainderValue;
/*     */   }
/*     */ 
/*     */   public void setRemainderValue(String value)
/*     */   {
/*  84 */     this.remainderValue = value;
/*     */   }
/*     */ 
/*     */   public String getPreConsumeTime()
/*     */   {
/*  96 */     return this.preConsumeTime;
/*     */   }
/*     */ 
/*     */   public void setPreConsumeTime(String value)
/*     */   {
/* 108 */     this.preConsumeTime = value;
/*     */   }
/*     */ 
/*     */   public String getResult()
/*     */   {
/* 120 */     return this.result;
/*     */   }
/*     */ 
/*     */   public void setResult(String value)
/*     */   {
/* 132 */     this.result = value;
/*     */   }
/*     */ 
/*     */   public String getResultMessage()
/*     */   {
/* 144 */     return this.resultMessage;
/*     */   }
/*     */ 
/*     */   public void setResultMessage(String value)
/*     */   {
/* 156 */     this.resultMessage = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 168 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 180 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.BizPublicInfoType
 * JD-Core Version:    0.6.0
 */