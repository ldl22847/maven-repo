/*    */ package cn.eshore.bnet.sdk.ap.exception;
/*    */ 
/*    */ public class ConvertDocToStringException extends Exception
/*    */ {
/*    */   public ConvertDocToStringException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConvertDocToStringException(String message, Throwable cause)
/*    */   {
/* 16 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ConvertDocToStringException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConvertDocToStringException(Throwable cause)
/*    */   {
/* 26 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.exception.ConvertDocToStringException
 * JD-Core Version:    0.6.0
 */