/*    */ package cn.eshore.bnet.sdk.ap.exception;
/*    */ 
/*    */ public class FetchXmlFromBnetException extends Exception
/*    */ {
/*    */   public FetchXmlFromBnetException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FetchXmlFromBnetException(String arg0, Throwable arg1)
/*    */   {
/* 16 */     super(arg0, arg1);
/*    */   }
/*    */ 
/*    */   public FetchXmlFromBnetException(String arg0)
/*    */   {
/* 21 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public FetchXmlFromBnetException(Throwable arg0)
/*    */   {
/* 26 */     super(arg0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.exception.FetchXmlFromBnetException
 * JD-Core Version:    0.6.0
 */