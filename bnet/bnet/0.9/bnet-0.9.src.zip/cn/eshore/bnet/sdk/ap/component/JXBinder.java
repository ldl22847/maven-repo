/*     */ package cn.eshore.bnet.sdk.ap.component;
/*     */ 
/*     */ import cn.eshore.bnet.sdk.ap.entity.MemberAttributeInfoType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ProductAttributeType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ResponseType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ReturnType;
/*     */ import cn.eshore.bnet.sdk.ap.exception.ConvertDocToStringException;
/*     */ import cn.eshore.bnet.sdk.ap.exception.ConvertJavaToXmlException;
/*     */ import cn.eshore.bnet.sdk.ap.exception.ConvertXmlToJavaException;
/*     */ import cn.eshore.bnet.sdk.ap.exception.FetchXmlFromBnetException;
/*     */ import cn.eshore.bnet.sdk.ap.utils.JavaBeanHelpler;
/*     */ import cn.eshore.bnet.sdk.ap.utils.Utils;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class JXBinder
/*     */ {
/*     */   private static final String MSG_CONVERT_XML_TO_JAVA_ERR = "Unable convert the xml to java.";
/*     */   private static final String MSG_CONVERT_JAVA_TO_XML_ERR = "Unable convert the java to xml.";
/*     */   private static final String MSG_FETCH_XML_ERR = "Unable fetch the xml from bnet.";
/*     */ 
/*     */   public static Object bindXml2Java(String getURL, String queryString)
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException
/*     */   {
/*  47 */     if (getURL.indexOf("?") >= 0)
/*  48 */       getURL = getURL + "&";
/*     */     else {
/*  50 */       getURL = getURL + "?";
/*     */     }
/*     */ 
/*  53 */     ResponseType response = new ResponseType();
/*     */     try
/*     */     {
/*  56 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*  57 */       DocumentBuilder db = dbf.newDocumentBuilder();
/*  58 */       Document doc = db.parse(getURL + queryString);
/*  59 */       Element element = doc.getDocumentElement();
/*     */ 
/*  61 */       convertElement2Obj(element, response);
/*     */     }
/*     */     catch (SecurityException e) {
/*  64 */       throw new ConvertXmlToJavaException("Unable convert the xml to java.", e);
/*     */     } catch (IllegalArgumentException e) {
/*  66 */       throw new ConvertXmlToJavaException("Unable convert the xml to java.", e);
/*     */     } catch (DOMException e) {
/*  68 */       throw new ConvertXmlToJavaException("Unable convert the xml to java.", e);
/*     */     } catch (NoSuchMethodException e) {
/*  70 */       throw new ConvertXmlToJavaException("Unable convert the xml to java.", e);
/*     */     } catch (IllegalAccessException e) {
/*  72 */       throw new ConvertXmlToJavaException("Unable convert the xml to java.", e);
/*     */     } catch (InvocationTargetException e) {
/*  74 */       throw new ConvertXmlToJavaException("Unable convert the xml to java.", e);
/*     */     } catch (InstantiationException e) {
/*  76 */       throw new ConvertXmlToJavaException("Unable convert the xml to java.", e);
/*     */     } catch (ParserConfigurationException e) {
/*  78 */       throw new FetchXmlFromBnetException("Unable fetch the xml from bnet.", e);
/*     */     } catch (SAXException e) {
/*  80 */       throw new FetchXmlFromBnetException("Unable fetch the xml from bnet.", e);
/*     */     } catch (IOException e) {
/*  82 */       throw new FetchXmlFromBnetException("Unable fetch the xml from bnet.", e);
/*     */     }
/*     */ 
/*  85 */     return response;
/*     */   }
/*     */ 
/*     */   public static String bindJava2Xml(Object obj) throws ConvertJavaToXmlException {
/*  89 */     ReturnType returnInfo = (ReturnType)obj;
/*     */     try {
/*  91 */       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
/*  92 */       DocumentBuilder db = dbf.newDocumentBuilder();
/*  93 */       Document doc = db.newDocument();
/*     */ 
/*  95 */       Node responseNode = doc.createElement("response");
/*     */ 
/*  97 */       Node operIdNode = doc.createElement("operId");
/*  98 */       Node operIdTextNode = doc.createTextNode(returnInfo.getOperId());
/*  99 */       operIdNode.appendChild(operIdTextNode);
/*     */ 
/* 101 */       Node resultNode = doc.createElement("result");
/* 102 */       Node resultTextNode = doc.createTextNode(returnInfo.getResult());
/* 103 */       resultNode.appendChild(resultTextNode);
/*     */ 
/* 105 */       Node resultMessageNode = doc.createElement("resultMessage");
/* 106 */       Node resultMessageTextNode = doc.createTextNode(returnInfo.getResultMessage());
/* 107 */       resultMessageNode.appendChild(resultMessageTextNode);
/*     */ 
/* 109 */       Node hashcodeNode = doc.createElement("hashcode");
/* 110 */       Node hashcodeTextNode = doc.createTextNode(returnInfo.getHashcode());
/* 111 */       hashcodeNode.appendChild(hashcodeTextNode);
/*     */ 
/* 113 */       responseNode.appendChild(operIdNode);
/* 114 */       responseNode.appendChild(resultNode);
/* 115 */       responseNode.appendChild(resultMessageNode);
/* 116 */       responseNode.appendChild(hashcodeNode);
/*     */ 
/* 118 */       return Utils.convertDocToString(responseNode);
/*     */     }
/*     */     catch (ParserConfigurationException e) {
/* 121 */       throw new ConvertJavaToXmlException("Unable convert the java to xml.", e); } catch (ConvertDocToStringException e) {
/*     */     }
/* 123 */     throw new ConvertJavaToXmlException("Unable convert the java to xml.", e);
/*     */   }
/*     */ 
/*     */   private static void convertElement2Obj(Element element, Object object)
/*     */     throws SecurityException, NoSuchMethodException, IllegalArgumentException, DOMException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/* 130 */     if (Utils.isNullObject(element)) {
/* 131 */       return;
/*     */     }
/* 133 */     Class objClazz = object.getClass();
/* 134 */     Method[] methods = objClazz.getMethods();
/* 135 */     if (!Utils.isNullOrEmptyArray(methods))
/* 136 */       for (int i = 0; i < methods.length; i++) {
/* 137 */         if ((!methods[i].getName().startsWith("get")) || (methods[i].getName().equals("getClass"))) {
/*     */           continue;
/*     */         }
/* 140 */         Method getMethod = methods[i];
/* 141 */         JavaBeanHelpler javaBeanHelpler = new JavaBeanHelpler(getMethod.getName());
/* 142 */         NodeList nodeList = element.getElementsByTagName(javaBeanHelpler.getFieldName());
/* 143 */         if (getMethod.getReturnType().equals(String.class)) {
/* 144 */           Method setMethod = objClazz.getMethod(javaBeanHelpler.getSetMethodName(), 
/* 145 */             new Class[] { String.class });
/* 146 */           if (!Utils.isNullObject(nodeList.item(0))) {
/* 147 */             setMethod.invoke(object, 
/* 148 */               new Object[] { nodeList.item(0).getChildNodes().item(0).getNodeValue() });
/*     */           }
/*     */ 
/*     */         }
/* 152 */         else if (getMethod.getReturnType().equals(List.class)) {
/* 153 */           Method getListMethod = objClazz.getMethod(javaBeanHelpler.getGetMethodName(), null);
/* 154 */           List list = (List)getListMethod.invoke(object, null);
/* 155 */           if (javaBeanHelpler.getFieldName().equals("productAttribute"))
/* 156 */             for (int j = 0; j < nodeList.getLength(); j++) {
/* 157 */               ProductAttributeType obj = new ProductAttributeType();
/* 158 */               Element attrElement = (Element)nodeList.item(j);
/* 159 */               Attr attr = (Attr)attrElement.getAttributes().getNamedItem("id");
/* 160 */               obj.setId(attr.getValue());
/* 161 */               if ((attrElement.getElementsByTagName("attributeValue").getLength() != 0) && 
/* 162 */                 (attrElement.getElementsByTagName("attributeValue").item(0).getChildNodes()
/* 163 */                 .getLength() != 0)) {
/* 164 */                 obj.setAttributeValue(attrElement.getElementsByTagName("attributeValue").item(0)
/* 165 */                   .getChildNodes().item(0).getNodeValue());
/*     */               }
/* 167 */               list.add(obj);
/*     */             }
/* 169 */           else if (javaBeanHelpler.getFieldName().equals("memberAttribute"))
/* 170 */             for (int j = 0; j < nodeList.getLength(); j++) {
/* 171 */               MemberAttributeInfoType obj = new MemberAttributeInfoType();
/* 172 */               Element attrElement = (Element)nodeList.item(j);
/* 173 */               Attr attr = (Attr)attrElement.getAttributes().getNamedItem("id");
/* 174 */               obj.setId(attr.getValue());
/* 175 */               if ((attrElement.getElementsByTagName("attributeValue").getLength() != 0) && 
/* 176 */                 (attrElement.getElementsByTagName("attributeValue").item(0).getChildNodes()
/* 177 */                 .getLength() != 0)) {
/* 178 */                 obj.setAttributeValue(attrElement.getElementsByTagName("attributeValue").item(0)
/* 179 */                   .getChildNodes().item(0).getNodeValue());
/*     */               }
/* 181 */               list.add(obj);
/*     */             }
/*     */         }
/*     */         else
/*     */         {
/* 186 */           if (nodeList.getLength() == 0) {
/*     */             continue;
/*     */           }
/* 189 */           Object obj = getMethod.getReturnType().newInstance();
/* 190 */           convertElement2Obj((Element)nodeList.item(0), obj);
/* 191 */           Method setMethod = objClazz.getMethod(javaBeanHelpler.getSetMethodName(), new Class[] { getMethod
/* 192 */             .getReturnType() });
/* 193 */           setMethod.invoke(object, new Object[] { obj });
/*     */         }
/*     */       }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.component.JXBinder
 * JD-Core Version:    0.6.0
 */