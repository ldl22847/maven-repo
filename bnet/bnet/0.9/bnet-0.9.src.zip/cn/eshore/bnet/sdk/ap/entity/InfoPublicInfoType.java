/*    */ package cn.eshore.bnet.sdk.ap.entity;
/*    */ 
/*    */ public class InfoPublicInfoType
/*    */ {
/*    */   protected String result;
/*    */   protected String resultMessage;
/*    */   protected String hashcode;
/*    */ 
/*    */   public String getResult()
/*    */   {
/* 21 */     return this.result;
/*    */   }
/*    */ 
/*    */   public void setResult(String value)
/*    */   {
/* 33 */     this.result = value;
/*    */   }
/*    */ 
/*    */   public String getResultMessage()
/*    */   {
/* 45 */     return this.resultMessage;
/*    */   }
/*    */ 
/*    */   public void setResultMessage(String value)
/*    */   {
/* 57 */     this.resultMessage = value;
/*    */   }
/*    */ 
/*    */   public String getHashcode()
/*    */   {
/* 69 */     return this.hashcode;
/*    */   }
/*    */ 
/*    */   public void setHashcode(String value)
/*    */   {
/* 81 */     this.hashcode = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.InfoPublicInfoType
 * JD-Core Version:    0.6.0
 */