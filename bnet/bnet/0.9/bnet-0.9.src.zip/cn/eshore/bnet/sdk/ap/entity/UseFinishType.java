/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class UseFinishType
/*     */ {
/*     */   protected String appSystemId;
/*     */   protected String useSessionId;
/*     */   protected String useValue;
/*     */   protected String timeStamp;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getAppSystemId()
/*     */   {
/*  23 */     return this.appSystemId;
/*     */   }
/*     */ 
/*     */   public void setAppSystemId(String value)
/*     */   {
/*  35 */     this.appSystemId = value;
/*     */   }
/*     */ 
/*     */   public String getUseSessionId()
/*     */   {
/*  47 */     return this.useSessionId;
/*     */   }
/*     */ 
/*     */   public void setUseSessionId(String value)
/*     */   {
/*  59 */     this.useSessionId = value;
/*     */   }
/*     */ 
/*     */   public String getUseValue()
/*     */   {
/*  71 */     return this.useValue;
/*     */   }
/*     */ 
/*     */   public void setUseValue(String value)
/*     */   {
/*  83 */     this.useValue = value;
/*     */   }
/*     */ 
/*     */   public String getTimeStamp()
/*     */   {
/*  95 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */   public void setTimeStamp(String value)
/*     */   {
/* 107 */     this.timeStamp = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 119 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 131 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.UseFinishType
 * JD-Core Version:    0.6.0
 */