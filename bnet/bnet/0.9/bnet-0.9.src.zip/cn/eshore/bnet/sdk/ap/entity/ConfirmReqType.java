/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class ConfirmReqType
/*     */ {
/*     */   protected String appSystemId;
/*     */   protected String requestId;
/*     */   protected String bnetId;
/*     */   protected String userAccountId;
/*     */   protected String timeStamp;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getAppSystemId()
/*     */   {
/*  24 */     return this.appSystemId;
/*     */   }
/*     */ 
/*     */   public void setAppSystemId(String value)
/*     */   {
/*  36 */     this.appSystemId = value;
/*     */   }
/*     */ 
/*     */   public String getRequestId()
/*     */   {
/*  48 */     return this.requestId;
/*     */   }
/*     */ 
/*     */   public void setRequestId(String value)
/*     */   {
/*  60 */     this.requestId = value;
/*     */   }
/*     */ 
/*     */   public String getBnetId()
/*     */   {
/*  72 */     return this.bnetId;
/*     */   }
/*     */ 
/*     */   public void setBnetId(String value)
/*     */   {
/*  84 */     this.bnetId = value;
/*     */   }
/*     */ 
/*     */   public String getUserAccountId()
/*     */   {
/*  96 */     return this.userAccountId;
/*     */   }
/*     */ 
/*     */   public void setUserAccountId(String value)
/*     */   {
/* 108 */     this.userAccountId = value;
/*     */   }
/*     */ 
/*     */   public String getTimeStamp()
/*     */   {
/* 120 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */   public void setTimeStamp(String value)
/*     */   {
/* 132 */     this.timeStamp = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 144 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 156 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.ConfirmReqType
 * JD-Core Version:    0.6.0
 */