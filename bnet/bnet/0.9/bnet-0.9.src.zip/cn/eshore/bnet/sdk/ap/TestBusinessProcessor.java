/*     */ package cn.eshore.bnet.sdk.ap;
/*     */ 
/*     */ import cn.eshore.bnet.sdk.ap.entity.BizPublicInfoType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.InfoPublicInfoType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ResponseType;
/*     */ import cn.eshore.bnet.sdk.ap.exception.BnetHashCodeIncorrectException;
/*     */ import cn.eshore.bnet.sdk.ap.exception.ConvertXmlToJavaException;
/*     */ import cn.eshore.bnet.sdk.ap.exception.FetchXmlFromBnetException;
/*     */ import junit.framework.TestCase;
/*     */ 
/*     */ public class TestBusinessProcessor extends TestCase
/*     */ {
/*     */   protected void setUp()
/*     */     throws Exception
/*     */   {
/*  12 */     super.setUp();
/*     */   }
/*     */ 
/*     */   protected void tearDown() throws Exception {
/*  16 */     super.tearDown();
/*     */   }
/*     */ 
/*     */   public void testQueryCustomer() throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/*  21 */     String bnetURL = "http://10.18.96.44:7801/ap/v4/BnetForApProxy";
/*  22 */     String appSystemId = "GD9900093";
/*  23 */     String shareKey = "1234567890ABCDEF";
/*  24 */     String bnetId = "GD140947240";
/*  25 */     String productId = "3542148";
/*     */ 
/*  27 */     ResponseType response = BusinessProcessor.queryCustomer(bnetURL, appSystemId, 
/*  28 */       bnetId, productId, shareKey);
/*     */ 
/*  30 */     assertEquals("10000", response.getInfoPublicInfo().getResult());
/*     */   }
/*     */ 
/*     */   public void testLogAuth()
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/*  36 */     String bnetURL = "http://10.18.96.44:7801/ap/v4/BnetForApProxy";
/*  37 */     String appSystemId = "GD9900093";
/*  38 */     String shareKey = "1234567890ABCDEF";
/*  39 */     String bnetAccount = "eshoretestxm05041";
/*  40 */     String password = "25D55AD283AA400AF464C76D713C07AD";
/*  41 */     String userAccount = "admin";
/*     */ 
/*  43 */     ResponseType response = BusinessProcessor.logAuth(bnetURL, appSystemId, userAccount, bnetAccount, 
/*  44 */       password, shareKey);
/*     */ 
/*  46 */     assertEquals("10000", response.getInfoPublicInfo().getResult());
/*     */   }
/*     */ 
/*     */   public void testConfirmReq()
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/*  53 */     String bnetURL = "http://10.18.96.44:7801/ap/v4/BnetForApProxy";
/*  54 */     String appSystemId = "GD9900093";
/*  55 */     String shareKey = "1234567890ABCDEF";
/*  56 */     String bnetId = "GD140947240";
/*  57 */     String requestId = "";
/*  58 */     String userAccountId = "983535";
/*     */ 
/*  60 */     ResponseType response = BusinessProcessor.confirmReq(bnetURL, appSystemId, userAccountId, bnetId, 
/*  61 */       requestId, shareKey);
/*     */ 
/*  63 */     assertEquals("10000", response.getInfoPublicInfo().getResult());
/*     */   }
/*     */ 
/*     */   public void testUserAuth()
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/*  70 */     String bnetURL = "http://10.18.96.44:7801/ap/v4/BnetForApProxy";
/*  71 */     String appSystemId = "GD9900093";
/*  72 */     String shareKey = "1234567890ABCDEF";
/*  73 */     String productId = "3542148";
/*  74 */     String userAccountId = "983535";
/*     */ 
/*  76 */     ResponseType response = BusinessProcessor.userAuth(bnetURL, appSystemId, userAccountId, 
/*  77 */       productId, shareKey);
/*     */ 
/*  79 */     assertEquals("10000", response.getInfoPublicInfo().getResult());
/*     */   }
/*     */ 
/*     */   public void testUseAuth()
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/*  86 */     String bnetURL = "http://10.18.96.44:7801/ap/v4/BnetForApProxy";
/*  87 */     String appSystemId = "GD9900093";
/*  88 */     String shareKey = "1234567890ABCDEF";
/*  89 */     String productId = "3542148";
/*  90 */     String userAccountId = "983535";
/*  91 */     String chargingType = "";
/*  92 */     String useSessionId = "-1";
/*  93 */     String useValue = "0";
/*     */ 
/*  95 */     ResponseType response = BusinessProcessor.useAuth(bnetURL, appSystemId, userAccountId, productId, 
/*  96 */       chargingType, useSessionId, useValue, shareKey);
/*     */ 
/*  98 */     assertEquals("10000", response.getBizPublicInfo().getResult());
/*     */   }
/*     */ 
/*     */   public void testUseFinish()
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/* 105 */     String bnetURL = "http://10.18.96.44:7801/ap/v4/BnetForApProxy";
/* 106 */     String appSystemId = "GD9900093";
/* 107 */     String shareKey = "1234567890ABCDEF";
/* 108 */     String useSessionId = "-1";
/* 109 */     String useValue = "0";
/*     */ 
/* 111 */     ResponseType response = BusinessProcessor.useFinish(bnetURL, appSystemId, 
/* 112 */       useSessionId, useValue, shareKey);
/*     */ 
/* 114 */     assertEquals("10000", response.getBizPublicInfo().getResult());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.TestBusinessProcessor
 * JD-Core Version:    0.6.0
 */