/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class ResponseType
/*     */ {
/*     */   protected OperPublicInfoType operPublicInfo;
/*     */   protected InfoPublicInfoType infoPublicInfo;
/*     */   protected BizPublicInfoType bizPublicInfo;
/*     */   protected BnetAccountInfoType bnetAccountInfo;
/*     */   protected BnetAccountExInfoType bnetAccountExInfo;
/*     */   protected UserAccountInfoType userAccountInfo;
/*     */   protected ProductInfoType productInfo;
/*     */   protected MemberInfoType memberInfo;
/*     */ 
/*     */   public OperPublicInfoType getOperPublicInfo()
/*     */   {
/*  26 */     return this.operPublicInfo;
/*     */   }
/*     */ 
/*     */   public void setOperPublicInfo(OperPublicInfoType value)
/*     */   {
/*  38 */     this.operPublicInfo = value;
/*     */   }
/*     */ 
/*     */   public InfoPublicInfoType getInfoPublicInfo()
/*     */   {
/*  50 */     return this.infoPublicInfo;
/*     */   }
/*     */ 
/*     */   public void setInfoPublicInfo(InfoPublicInfoType value)
/*     */   {
/*  62 */     this.infoPublicInfo = value;
/*     */   }
/*     */ 
/*     */   public BizPublicInfoType getBizPublicInfo()
/*     */   {
/*  74 */     return this.bizPublicInfo;
/*     */   }
/*     */ 
/*     */   public void setBizPublicInfo(BizPublicInfoType value)
/*     */   {
/*  86 */     this.bizPublicInfo = value;
/*     */   }
/*     */ 
/*     */   public BnetAccountInfoType getBnetAccountInfo()
/*     */   {
/*  98 */     return this.bnetAccountInfo;
/*     */   }
/*     */ 
/*     */   public void setBnetAccountInfo(BnetAccountInfoType value)
/*     */   {
/* 110 */     this.bnetAccountInfo = value;
/*     */   }
/*     */ 
/*     */   public BnetAccountExInfoType getBnetAccountExInfo()
/*     */   {
/* 122 */     return this.bnetAccountExInfo;
/*     */   }
/*     */ 
/*     */   public void setBnetAccountExInfo(BnetAccountExInfoType value)
/*     */   {
/* 134 */     this.bnetAccountExInfo = value;
/*     */   }
/*     */ 
/*     */   public UserAccountInfoType getUserAccountInfo()
/*     */   {
/* 146 */     return this.userAccountInfo;
/*     */   }
/*     */ 
/*     */   public void setUserAccountInfo(UserAccountInfoType value)
/*     */   {
/* 158 */     this.userAccountInfo = value;
/*     */   }
/*     */ 
/*     */   public ProductInfoType getProductInfo()
/*     */   {
/* 170 */     return this.productInfo;
/*     */   }
/*     */ 
/*     */   public void setProductInfo(ProductInfoType value)
/*     */   {
/* 182 */     this.productInfo = value;
/*     */   }
/*     */ 
/*     */   public MemberInfoType getMemberInfo()
/*     */   {
/* 194 */     return this.memberInfo;
/*     */   }
/*     */ 
/*     */   public void setMemberInfo(MemberInfoType value)
/*     */   {
/* 206 */     this.memberInfo = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.ResponseType
 * JD-Core Version:    0.6.0
 */