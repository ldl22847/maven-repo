/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class QueryCustomerType
/*     */ {
/*     */   protected String appSystemId;
/*     */   protected String bnetId;
/*     */   protected String productId;
/*     */   protected String timeStamp;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getAppSystemId()
/*     */   {
/*  23 */     return this.appSystemId;
/*     */   }
/*     */ 
/*     */   public void setAppSystemId(String value)
/*     */   {
/*  35 */     this.appSystemId = value;
/*     */   }
/*     */ 
/*     */   public String getBnetId()
/*     */   {
/*  47 */     return this.bnetId;
/*     */   }
/*     */ 
/*     */   public void setBnetId(String value)
/*     */   {
/*  59 */     this.bnetId = value;
/*     */   }
/*     */ 
/*     */   public String getProductId()
/*     */   {
/*  71 */     return this.productId;
/*     */   }
/*     */ 
/*     */   public void setProductId(String value)
/*     */   {
/*  83 */     this.productId = value;
/*     */   }
/*     */ 
/*     */   public String getTimeStamp()
/*     */   {
/*  95 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */   public void setTimeStamp(String value)
/*     */   {
/* 107 */     this.timeStamp = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 119 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 131 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.QueryCustomerType
 * JD-Core Version:    0.6.0
 */