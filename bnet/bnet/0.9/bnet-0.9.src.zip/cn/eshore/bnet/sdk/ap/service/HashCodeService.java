/*     */ package cn.eshore.bnet.sdk.ap.service;
/*     */ 
/*     */ import cn.eshore.bnet.sdk.ap.entity.ConfirmReqType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.LogAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.QueryCustomerType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.QueryOperType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ReplyOperType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ReturnType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UseAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UseFinishType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UserAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.utils.MD5Crypter;
/*     */ 
/*     */ public class HashCodeService
/*     */ {
/*     */   public static void fillHashCode(Object object, String shareKey)
/*     */   {
/*  23 */     if ((object instanceof QueryOperType))
/*  24 */       fillQueryOper((QueryOperType)object, shareKey);
/*  25 */     else if ((object instanceof ReplyOperType))
/*  26 */       fillReplyOper((ReplyOperType)object, shareKey);
/*  27 */     else if ((object instanceof QueryCustomerType))
/*  28 */       fillQueryCustomerType((QueryCustomerType)object, shareKey);
/*  29 */     else if ((object instanceof LogAuthType))
/*  30 */       fillLogAuthType((LogAuthType)object, shareKey);
/*  31 */     else if ((object instanceof ConfirmReqType))
/*  32 */       fillConfirmReqType((ConfirmReqType)object, shareKey);
/*  33 */     else if ((object instanceof UserAuthType))
/*  34 */       fillUserAuthType((UserAuthType)object, shareKey);
/*  35 */     else if ((object instanceof UseAuthType))
/*  36 */       fillUseAuthType((UseAuthType)object, shareKey);
/*  37 */     else if ((object instanceof UseFinishType))
/*  38 */       fillUseFinishType((UseFinishType)object, shareKey);
/*  39 */     else if ((object instanceof ReturnType))
/*  40 */       fillReturnInfo((ReturnType)object, shareKey);
/*     */   }
/*     */ 
/*     */   private static void fillQueryOper(QueryOperType queryOper, String shareKey)
/*     */   {
/*  45 */     StringBuffer sb = new StringBuffer();
/*  46 */     sb.append("gdbnet.queryOper");
/*  47 */     sb.append(queryOper.getOperId());
/*  48 */     sb.append(queryOper.getAppSystemId());
/*  49 */     sb.append(queryOper.getTimeStamp());
/*  50 */     sb.append(shareKey);
/*     */ 
/*  52 */     queryOper.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillReplyOper(ReplyOperType replyOper, String shareKey)
/*     */   {
/*  57 */     StringBuffer sb = new StringBuffer();
/*  58 */     sb.append("gdbnet.replyOper");
/*  59 */     sb.append(replyOper.getOperId());
/*  60 */     sb.append(replyOper.getAppSystemId());
/*  61 */     sb.append(replyOper.getResult());
/*  62 */     sb.append(replyOper.getTimeStamp());
/*  63 */     sb.append(shareKey);
/*     */ 
/*  65 */     replyOper.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillQueryCustomerType(QueryCustomerType type, String shareKey)
/*     */   {
/*  71 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*  73 */     sb.append("gdbnet.queryCustomer");
/*  74 */     sb.append(type.getAppSystemId());
/*  75 */     sb.append(type.getBnetId());
/*  76 */     sb.append(type.getProductId());
/*  77 */     sb.append(type.getTimeStamp());
/*  78 */     sb.append(shareKey);
/*     */ 
/*  80 */     type.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillLogAuthType(LogAuthType type, String shareKey)
/*     */   {
/*  85 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*  87 */     sb.append("gdbnet.logAuth");
/*  88 */     sb.append(type.getAppSystemId());
/*  89 */     sb.append(type.getBnetAccount());
/*  90 */     sb.append(type.getUserAccount());
/*  91 */     sb.append(type.getPassword());
/*  92 */     sb.append(type.getTimeStamp());
/*  93 */     sb.append(shareKey);
/*     */ 
/*  95 */     type.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillConfirmReqType(ConfirmReqType type, String shareKey)
/*     */   {
/* 100 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 102 */     sb.append("gdbnet.confirmReq");
/* 103 */     sb.append(type.getAppSystemId());
/* 104 */     sb.append(type.getRequestId());
/* 105 */     sb.append(type.getBnetId());
/* 106 */     sb.append(type.getUserAccountId());
/* 107 */     sb.append(type.getTimeStamp());
/* 108 */     sb.append(shareKey);
/*     */ 
/* 110 */     type.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillUserAuthType(UserAuthType type, String shareKey)
/*     */   {
/* 115 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 117 */     sb.append("gdbnet.userAuth");
/* 118 */     sb.append(type.getAppSystemId());
/* 119 */     sb.append(type.getUserAccountId());
/* 120 */     sb.append(type.getProductId());
/* 121 */     sb.append(type.getTimeStamp());
/* 122 */     sb.append(shareKey);
/*     */ 
/* 124 */     type.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillUseAuthType(UseAuthType type, String shareKey)
/*     */   {
/* 129 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 131 */     sb.append("gdbnet.useAuth");
/* 132 */     sb.append(type.getAppSystemId());
/* 133 */     sb.append(type.getUserAccountId());
/* 134 */     sb.append(type.getProductId());
/* 135 */     sb.append(type.getUseSessionId());
/* 136 */     sb.append(type.getUseValue());
/* 137 */     sb.append(type.getChargingType());
/* 138 */     sb.append(type.getTimeStamp());
/* 139 */     sb.append(shareKey);
/*     */ 
/* 141 */     type.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillUseFinishType(UseFinishType type, String shareKey)
/*     */   {
/* 147 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 149 */     sb.append("gdbnet.useFinish");
/* 150 */     sb.append(type.getAppSystemId());
/* 151 */     sb.append(type.getUseSessionId());
/* 152 */     sb.append(type.getUseValue());
/* 153 */     sb.append(type.getTimeStamp());
/* 154 */     sb.append(shareKey);
/*     */ 
/* 156 */     type.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ 
/*     */   private static void fillReturnInfo(ReturnType returnInfo, String shareKey) {
/* 160 */     StringBuffer sb = new StringBuffer();
/* 161 */     sb.append(returnInfo.getOperId());
/* 162 */     sb.append(returnInfo.getResult());
/* 163 */     sb.append(shareKey);
/*     */ 
/* 165 */     returnInfo.setHashcode(MD5Crypter.MD5Encode(sb.toString()));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.service.HashCodeService
 * JD-Core Version:    0.6.0
 */