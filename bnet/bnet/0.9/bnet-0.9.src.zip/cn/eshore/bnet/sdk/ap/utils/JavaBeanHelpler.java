/*    */ package cn.eshore.bnet.sdk.ap.utils;
/*    */ 
/*    */ public class JavaBeanHelpler
/*    */ {
/*    */   private String fieldName;
/*    */   private String getMethodName;
/*    */   private String setMethodName;
/*    */ 
/*    */   public JavaBeanHelpler(String getMethodName)
/*    */   {
/* 11 */     this.getMethodName = getMethodName;
/* 12 */     setFieldName(getMethodName);
/* 13 */     setSetFieldName(getMethodName);
/*    */   }
/*    */ 
/*    */   public String getFieldName()
/*    */   {
/* 21 */     return this.fieldName;
/*    */   }
/*    */ 
/*    */   public String getGetMethodName() {
/* 25 */     return this.getMethodName;
/*    */   }
/*    */ 
/*    */   public String getSetMethodName() {
/* 29 */     return this.setMethodName;
/*    */   }
/*    */ 
/*    */   private void setFieldName(String getMethodName) {
/* 33 */     this.fieldName = getMethodName.replaceFirst("get", "");
/* 34 */     this.fieldName = this.fieldName.replaceFirst(String.valueOf(this.fieldName.charAt(0)), String.valueOf(
/* 35 */       this.fieldName.charAt(0)).toLowerCase());
/*    */   }
/*    */ 
/*    */   private void setSetFieldName(String getMethodName) {
/* 39 */     this.setMethodName = getMethodName.replaceFirst("get", "set");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.utils.JavaBeanHelpler
 * JD-Core Version:    0.6.0
 */