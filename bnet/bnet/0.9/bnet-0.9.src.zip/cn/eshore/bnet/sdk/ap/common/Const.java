package cn.eshore.bnet.sdk.ap.common;

public class Const
{
  public static final String SERV_NAME_QUERYOPER = "gdbnet.queryOper";
  public static final String SERV_NAME_REPLYOPER = "gdbnet.replyOper";
  public static final String SERV_NAME_QUERYCUSTOMER = "gdbnet.queryCustomer";
  public static final String SERV_NAME_LOGAUTH = "gdbnet.logAuth";
  public static final String SERV_NAME_CONFIRMREQ = "gdbnet.confirmReq";
  public static final String SERV_NAME_USERAUTH = "gdbnet.userAuth";
  public static final String SERV_NAME_USEAUTH = "gdbnet.useAuth";
  public static final String SERV_NAME_USEFINISH = "gdbnet.useFinish";
}

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.common.Const
 * JD-Core Version:    0.6.0
 */