/*    */ package cn.eshore.bnet.sdk.ap.entity;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MemberInfoType
/*    */ {
/*    */   protected String memberId;
/*    */   protected String accNum;
/*    */   protected String memberState;
/*    */   protected List memberAttribute;
/*    */ 
/*    */   public String getMemberId()
/*    */   {
/* 24 */     return this.memberId;
/*    */   }
/*    */ 
/*    */   public void setMemberId(String value)
/*    */   {
/* 36 */     this.memberId = value;
/*    */   }
/*    */ 
/*    */   public String getAccNum() {
/* 40 */     return this.accNum;
/*    */   }
/*    */ 
/*    */   public void setAccNum(String accNum) {
/* 44 */     this.accNum = accNum;
/*    */   }
/*    */ 
/*    */   public String getMemberState() {
/* 48 */     return this.memberState;
/*    */   }
/*    */ 
/*    */   public void setMemberState(String memberState) {
/* 52 */     this.memberState = memberState;
/*    */   }
/*    */ 
/*    */   public List getMemberAttribute()
/*    */   {
/* 78 */     if (this.memberAttribute == null) {
/* 79 */       this.memberAttribute = new ArrayList();
/*    */     }
/* 81 */     return this.memberAttribute;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.MemberInfoType
 * JD-Core Version:    0.6.0
 */