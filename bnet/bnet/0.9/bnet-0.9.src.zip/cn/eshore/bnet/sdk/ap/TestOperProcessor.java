/*    */ package cn.eshore.bnet.sdk.ap;
/*    */ 
/*    */ import cn.eshore.bnet.sdk.ap.entity.OperPublicInfoType;
/*    */ import cn.eshore.bnet.sdk.ap.entity.ResponseType;
/*    */ import cn.eshore.bnet.sdk.ap.exception.BnetHashCodeIncorrectException;
/*    */ import cn.eshore.bnet.sdk.ap.exception.ConvertXmlToJavaException;
/*    */ import cn.eshore.bnet.sdk.ap.exception.FetchXmlFromBnetException;
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ public class TestOperProcessor extends TestCase
/*    */ {
/*    */   protected void setUp()
/*    */     throws Exception
/*    */   {
/* 17 */     super.setUp();
/*    */   }
/*    */ 
/*    */   protected void tearDown() throws Exception {
/* 21 */     super.tearDown();
/*    */   }
/*    */ 
/*    */   public void testQueryOper() throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*    */   {
/* 26 */     String bnetURL = "http://10.18.96.73:7301/ap/v4/BnetForApProxy";
/* 27 */     String operId = "20101029090651825";
/* 28 */     String appSystemId = "GD9900084";
/* 29 */     String shareKey = "1234567890ABCDEF";
/*    */ 
/* 31 */     ResponseType response = OperProcessor.queryOper(bnetURL, operId, appSystemId, shareKey);
/*    */ 
/* 33 */     assertEquals("10000", response.getOperPublicInfo().getResult());
/* 34 */     assertEquals("addMember", response.getOperPublicInfo().getOperType());
/*    */   }
/*    */ 
/*    */   public void testReplyOper()
/*    */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*    */   {
/* 49 */     String bnetURL = "http://10.18.96.44:7801/ap/v4/BnetForApProxy";
/* 50 */     String operId = "20100304113006106";
/* 51 */     String appSystemId = "GD9900093";
/* 52 */     String shareKey = "1234567890ABCDEF";
/*    */ 
/* 55 */     ResponseType response = OperProcessor.replyOper(bnetURL, operId, appSystemId, "20000", "OK", shareKey);
/*    */ 
/* 57 */     assertEquals("10000", response.getOperPublicInfo().getResult());
/* 58 */     assertEquals("newProd", response.getOperPublicInfo().getOperType());
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.TestOperProcessor
 * JD-Core Version:    0.6.0
 */