/*    */ package cn.eshore.bnet.sdk.ap.utils;
/*    */ 
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ public class TestJavaBeanHelpler extends TestCase
/*    */ {
/*    */   protected void setUp()
/*    */     throws Exception
/*    */   {
/* 13 */     super.setUp();
/*    */   }
/*    */ 
/*    */   protected void tearDown() throws Exception {
/* 17 */     super.tearDown();
/*    */   }
/*    */ 
/*    */   public void test() {
/* 21 */     JavaBeanHelpler javaBeanHelpler = new JavaBeanHelpler("getAbcDef");
/* 22 */     assertEquals("getAbcDef", javaBeanHelpler.getGetMethodName());
/* 23 */     assertEquals("setAbcDef", javaBeanHelpler.getSetMethodName());
/* 24 */     assertEquals("abcDef", javaBeanHelpler.getFieldName());
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.utils.TestJavaBeanHelpler
 * JD-Core Version:    0.6.0
 */