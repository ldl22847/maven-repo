/*     */ package cn.eshore.bnet.sdk.ap;
/*     */ 
/*     */ import cn.eshore.bnet.sdk.ap.component.JXBinder;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ConfirmReqType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.LogAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.QueryCustomerType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ResponseType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UseAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UseFinishType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UserAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.exception.BnetHashCodeIncorrectException;
/*     */ import cn.eshore.bnet.sdk.ap.exception.ConvertXmlToJavaException;
/*     */ import cn.eshore.bnet.sdk.ap.exception.FetchXmlFromBnetException;
/*     */ import cn.eshore.bnet.sdk.ap.service.HashCodeService;
/*     */ import cn.eshore.bnet.sdk.ap.service.QueryParamService;
/*     */ import cn.eshore.bnet.sdk.ap.utils.Utils;
/*     */ 
/*     */ public class BusinessProcessor
/*     */ {
/*     */   public static ResponseType queryCustomer(String bnetURL, String appSystemId, String bnetId, String productId, String shareKey)
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/*  43 */     QueryCustomerType qcy = new QueryCustomerType();
/*     */ 
/*  45 */     qcy.setAppSystemId(appSystemId);
/*  46 */     qcy.setBnetId(bnetId);
/*  47 */     qcy.setProductId(productId);
/*  48 */     qcy.setTimeStamp(Utils.getTimeStampStr());
/*  49 */     HashCodeService.fillHashCode(qcy, shareKey);
/*     */ 
/*  51 */     String queryString = QueryParamService.generateQueryString(qcy);
/*     */ 
/*  53 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*     */ 
/*  55 */     return response;
/*     */   }
/*     */ 
/*     */   public static ResponseType logAuth(String bnetURL, String appSystemId, String userAccount, String bnetAccount, String password, String shareKey)
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/*  77 */     LogAuthType logAuth = new LogAuthType();
/*     */ 
/*  79 */     logAuth.setAppSystemId(appSystemId);
/*  80 */     logAuth.setBnetAccount(bnetAccount);
/*  81 */     logAuth.setPassword(password);
/*  82 */     logAuth.setUserAccount(userAccount);
/*  83 */     logAuth.setTimeStamp(Utils.getTimeStampStr());
/*  84 */     HashCodeService.fillHashCode(logAuth, shareKey);
/*     */ 
/*  87 */     String queryString = QueryParamService.generateQueryString(logAuth);
/*     */ 
/*  89 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*     */ 
/*  91 */     return response;
/*     */   }
/*     */ 
/*     */   public static ResponseType confirmReq(String bnetURL, String appSystemId, String userAccountId, String bnetId, String requestId, String shareKey)
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/* 111 */     ConfirmReqType confirmReq = new ConfirmReqType();
/*     */ 
/* 113 */     confirmReq.setAppSystemId(appSystemId);
/* 114 */     confirmReq.setBnetId(bnetId);
/* 115 */     confirmReq.setRequestId(requestId);
/* 116 */     confirmReq.setUserAccountId(userAccountId);
/* 117 */     confirmReq.setTimeStamp(Utils.getTimeStampStr());
/* 118 */     HashCodeService.fillHashCode(confirmReq, shareKey);
/*     */ 
/* 120 */     String queryString = QueryParamService.generateQueryString(confirmReq);
/*     */ 
/* 122 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*     */ 
/* 124 */     return response;
/*     */   }
/*     */ 
/*     */   public static ResponseType userAuth(String bnetURL, String appSystemId, String userAccountId, String productId, String shareKey)
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/* 145 */     UserAuthType userAuth = new UserAuthType();
/*     */ 
/* 147 */     userAuth.setAppSystemId(appSystemId);
/* 148 */     userAuth.setProductId(productId);
/* 149 */     userAuth.setUserAccountId(userAccountId);
/* 150 */     userAuth.setTimeStamp(Utils.getTimeStampStr());
/* 151 */     HashCodeService.fillHashCode(userAuth, shareKey);
/*     */ 
/* 154 */     String queryString = QueryParamService.generateQueryString(userAuth);
/*     */ 
/* 156 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*     */ 
/* 158 */     return response;
/*     */   }
/*     */ 
/*     */   public static ResponseType useAuth(String bnetURL, String appSystemId, String userAccountId, String productId, String chargingType, String useSessionId, String useValue, String shareKey)
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/* 182 */     UseAuthType useAuth = new UseAuthType();
/*     */ 
/* 184 */     useAuth.setAppSystemId(appSystemId);
/* 185 */     useAuth.setChargingType(chargingType);
/* 186 */     useAuth.setUseSessionId(useSessionId);
/* 187 */     useAuth.setUseValue(useValue);
/* 188 */     useAuth.setProductId(productId);
/* 189 */     useAuth.setUserAccountId(userAccountId);
/* 190 */     useAuth.setTimeStamp(Utils.getTimeStampStr());
/* 191 */     HashCodeService.fillHashCode(useAuth, shareKey);
/*     */ 
/* 195 */     String queryString = QueryParamService.generateQueryString(useAuth);
/*     */ 
/* 197 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*     */ 
/* 199 */     return response;
/*     */   }
/*     */ 
/*     */   public static ResponseType useFinish(String bnetURL, String appSystemId, String useSessionId, String useValue, String shareKey)
/*     */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*     */   {
/* 219 */     UseFinishType useFinish = new UseFinishType();
/*     */ 
/* 221 */     useFinish.setAppSystemId(appSystemId);
/* 222 */     useFinish.setUseSessionId(useSessionId);
/* 223 */     useFinish.setUseValue(useValue);
/* 224 */     useFinish.setTimeStamp(Utils.getTimeStampStr());
/* 225 */     HashCodeService.fillHashCode(useFinish, shareKey);
/*     */ 
/* 228 */     String queryString = QueryParamService.generateQueryString(useFinish);
/*     */ 
/* 230 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*     */ 
/* 232 */     return response;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.BusinessProcessor
 * JD-Core Version:    0.6.0
 */