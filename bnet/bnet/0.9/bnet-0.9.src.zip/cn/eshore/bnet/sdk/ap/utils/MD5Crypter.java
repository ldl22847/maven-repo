/*    */ package cn.eshore.bnet.sdk.ap.utils;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ 
/*    */ public class MD5Crypter
/*    */ {
/* 14 */   private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 
/* 15 */     'e', 'f' };
/*    */   private static final String UTF8 = "utf8";
/*    */   private static final String MD5 = "MD5";
/*    */ 
/*    */   public static String MD5Encode(String originalString)
/*    */   {
/*    */     try
/*    */     {
/* 23 */       byte[] originalBytes = originalString.getBytes("utf8");
/* 24 */       MessageDigest md = MessageDigest.getInstance("MD5");
/* 25 */       md.update(originalBytes);
/* 26 */       byte[] temps = md.digest();
/* 27 */       int j = temps.length;
/* 28 */       char[] str = new char[j * 2];
/* 29 */       int k = 0;
/* 30 */       for (int i = 0; i < j; i++) {
/* 31 */         byte tempByte = temps[i];
/* 32 */         str[(k++)] = HEX_DIGITS[(tempByte >>> 4 & 0xF)];
/* 33 */         str[(k++)] = HEX_DIGITS[(tempByte & 0xF)];
/*    */       }
/* 35 */       return new String(str).toUpperCase();
/*    */     }
/*    */     catch (UnsupportedEncodingException e)
/*    */     {
/* 39 */       e.printStackTrace();
/*    */     }
/*    */     catch (NoSuchAlgorithmException e) {
/* 42 */       e.printStackTrace();
/*    */     }
/*    */ 
/* 45 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.utils.MD5Crypter
 * JD-Core Version:    0.6.0
 */