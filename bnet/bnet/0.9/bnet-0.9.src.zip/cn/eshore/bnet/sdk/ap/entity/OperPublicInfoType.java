/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class OperPublicInfoType
/*     */ {
/*     */   protected String operId;
/*     */   protected String operType;
/*     */   protected String bnetId;
/*     */   protected String productId;
/*     */   protected String result;
/*     */   protected String resultMessage;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getOperId()
/*     */   {
/*  20 */     return this.operId;
/*     */   }
/*     */ 
/*     */   public void setOperId(String value)
/*     */   {
/*  31 */     this.operId = value;
/*     */   }
/*     */ 
/*     */   public String getOperType()
/*     */   {
/*  41 */     return this.operType;
/*     */   }
/*     */ 
/*     */   public void setOperType(String value)
/*     */   {
/*  52 */     this.operType = value;
/*     */   }
/*     */ 
/*     */   public String getBnetId()
/*     */   {
/*  62 */     return this.bnetId;
/*     */   }
/*     */ 
/*     */   public void setBnetId(String value)
/*     */   {
/*  73 */     this.bnetId = value;
/*     */   }
/*     */ 
/*     */   public String getProductId()
/*     */   {
/*  83 */     return this.productId;
/*     */   }
/*     */ 
/*     */   public void setProductId(String value)
/*     */   {
/*  94 */     this.productId = value;
/*     */   }
/*     */ 
/*     */   public String getResult()
/*     */   {
/* 104 */     return this.result;
/*     */   }
/*     */ 
/*     */   public void setResult(String value)
/*     */   {
/* 115 */     this.result = value;
/*     */   }
/*     */ 
/*     */   public String getResultMessage()
/*     */   {
/* 125 */     return this.resultMessage;
/*     */   }
/*     */ 
/*     */   public void setResultMessage(String value)
/*     */   {
/* 136 */     this.resultMessage = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/* 146 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 157 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.OperPublicInfoType
 * JD-Core Version:    0.6.0
 */