/*    */ package cn.eshore.bnet.sdk.ap;
/*    */ 
/*    */ import cn.eshore.bnet.sdk.ap.component.JXBinder;
/*    */ import cn.eshore.bnet.sdk.ap.entity.OperPublicInfoType;
/*    */ import cn.eshore.bnet.sdk.ap.entity.QueryOperType;
/*    */ import cn.eshore.bnet.sdk.ap.entity.ReplyOperType;
/*    */ import cn.eshore.bnet.sdk.ap.entity.ResponseType;
/*    */ import cn.eshore.bnet.sdk.ap.exception.BnetHashCodeIncorrectException;
/*    */ import cn.eshore.bnet.sdk.ap.exception.ConvertXmlToJavaException;
/*    */ import cn.eshore.bnet.sdk.ap.exception.FetchXmlFromBnetException;
/*    */ import cn.eshore.bnet.sdk.ap.service.HashCodeService;
/*    */ import cn.eshore.bnet.sdk.ap.service.QueryParamService;
/*    */ import cn.eshore.bnet.sdk.ap.utils.MD5Validator;
/*    */ import cn.eshore.bnet.sdk.ap.utils.Utils;
/*    */ 
/*    */ public class OperProcessor
/*    */ {
/*    */   public static ResponseType queryOper(String bnetURL, String operId, String appSystemId, String shareKey)
/*    */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*    */   {
/* 38 */     QueryOperType queryOper = new QueryOperType();
/*    */ 
/* 40 */     queryOper.setOperId(operId);
/* 41 */     queryOper.setAppSystemId(appSystemId);
/* 42 */     queryOper.setTimeStamp(Utils.getTimeStampStr());
/* 43 */     HashCodeService.fillHashCode(queryOper, shareKey);
/*    */ 
/* 45 */     String queryString = QueryParamService.generateQueryString(queryOper);
/*    */ 
/* 47 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*    */ 
/* 49 */     validateOperPublicInfoHashcode(response.getOperPublicInfo(), shareKey);
/*    */ 
/* 51 */     return response;
/*    */   }
/*    */ 
/*    */   public static ResponseType replyOper(String bnetURL, String operId, String appSystemId, String result, String resultMessage, String shareKey)
/*    */     throws ConvertXmlToJavaException, FetchXmlFromBnetException, BnetHashCodeIncorrectException
/*    */   {
/* 72 */     ReplyOperType replyOper = new ReplyOperType();
/* 73 */     replyOper.setOperId(operId);
/* 74 */     replyOper.setAppSystemId(appSystemId);
/* 75 */     replyOper.setResult(result);
/* 76 */     replyOper.setResultMessage(resultMessage);
/* 77 */     replyOper.setTimeStamp(Utils.getTimeStampStr());
/* 78 */     HashCodeService.fillHashCode(replyOper, shareKey);
/*    */ 
/* 80 */     String queryString = QueryParamService.generateQueryString(replyOper);
/*    */ 
/* 82 */     ResponseType response = (ResponseType)JXBinder.bindXml2Java(bnetURL, queryString);
/*    */ 
/* 84 */     validateOperPublicInfoHashcode(response.getOperPublicInfo(), shareKey);
/*    */ 
/* 86 */     return response;
/*    */   }
/*    */ 
/*    */   private static void validateOperPublicInfoHashcode(OperPublicInfoType operPublicInfo, String shareKey)
/*    */     throws BnetHashCodeIncorrectException
/*    */   {
/* 92 */     if (!MD5Validator.validate(new String[] { operPublicInfo.getOperId(), 
/* 93 */       operPublicInfo.getOperType(), operPublicInfo.getBnetId(), 
/* 94 */       operPublicInfo.getProductId(), operPublicInfo.getResult(), 
/* 95 */       shareKey }, operPublicInfo.getHashcode()))
/* 96 */       throw new BnetHashCodeIncorrectException(
/* 97 */         "The hashcode returned by bnet is incorrect");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.OperProcessor
 * JD-Core Version:    0.6.0
 */