/*    */ package cn.eshore.bnet.sdk.ap.exception;
/*    */ 
/*    */ public class ConvertJavaToXmlException extends Exception
/*    */ {
/*    */   public ConvertJavaToXmlException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConvertJavaToXmlException(String message, Throwable cause)
/*    */   {
/* 16 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ConvertJavaToXmlException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConvertJavaToXmlException(Throwable cause)
/*    */   {
/* 26 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.exception.ConvertJavaToXmlException
 * JD-Core Version:    0.6.0
 */