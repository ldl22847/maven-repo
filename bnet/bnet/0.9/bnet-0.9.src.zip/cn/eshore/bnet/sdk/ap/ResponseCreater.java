/*    */ package cn.eshore.bnet.sdk.ap;
/*    */ 
/*    */ import cn.eshore.bnet.sdk.ap.entity.ReturnType;
/*    */ import cn.eshore.bnet.sdk.ap.service.HashCodeService;
/*    */ 
/*    */ public class ResponseCreater
/*    */ {
/*    */   private static final String RETURN_XML_PART_ONE = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><response><operId>";
/*    */   private static final String RETURN_XML_PART_TWO = "</operId><result>";
/*    */   private static final String RETURN_XML_PART_THREE = "</result><resultMessage>";
/*    */   private static final String RETURN_XML_PART_FOUR = "</resultMessage><hashcode>";
/*    */   private static final String RETURN_XML_PART_FIVE = "</hashcode></response>";
/*    */ 
/*    */   public static String createResponse(String operId, String result, String resultMessage, String shareKey)
/*    */   {
/* 29 */     ReturnType returnInfo = new ReturnType();
/* 30 */     returnInfo.setOperId(operId);
/* 31 */     returnInfo.setResult(result);
/* 32 */     returnInfo.setResultMessage(resultMessage);
/* 33 */     HashCodeService.fillHashCode(returnInfo, shareKey);
/*    */ 
/* 35 */     StringBuffer sb = new StringBuffer();
/* 36 */     sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><response><operId>");
/* 37 */     sb.append(returnInfo.getOperId());
/* 38 */     sb.append("</operId><result>");
/* 39 */     sb.append(returnInfo.getResult());
/* 40 */     sb.append("</result><resultMessage>");
/* 41 */     sb.append(returnInfo.getResultMessage());
/* 42 */     sb.append("</resultMessage><hashcode>");
/* 43 */     sb.append(returnInfo.getHashcode());
/* 44 */     sb.append("</hashcode></response>");
/*    */ 
/* 46 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.ResponseCreater
 * JD-Core Version:    0.6.0
 */