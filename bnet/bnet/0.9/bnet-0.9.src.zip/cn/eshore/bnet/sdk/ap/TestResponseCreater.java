/*    */ package cn.eshore.bnet.sdk.ap;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ public class TestResponseCreater extends TestCase
/*    */ {
/*    */   protected void setUp()
/*    */     throws Exception
/*    */   {
/* 13 */     super.setUp();
/*    */   }
/*    */ 
/*    */   protected void tearDown() throws Exception {
/* 17 */     super.tearDown();
/*    */   }
/*    */ 
/*    */   public void test()
/*    */   {
/* 22 */     String operId = "20100301175616161";
/* 23 */     String result = "20000";
/* 24 */     String resultMessage = "success";
/* 25 */     String shareKey = "1234567890ABCDEF";
/*    */ 
/* 27 */     System.out.println(ResponseCreater.createResponse(operId, result, resultMessage, shareKey));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.TestResponseCreater
 * JD-Core Version:    0.6.0
 */