/*    */ package cn.eshore.bnet.sdk.ap.entity;
/*    */ 
/*    */ public class BnetAccountInfoType
/*    */ {
/*    */   protected String bnetId;
/*    */   protected String bnetAccount;
/*    */   protected String customerName;
/*    */ 
/*    */   public String getBnetId()
/*    */   {
/* 20 */     return this.bnetId;
/*    */   }
/*    */ 
/*    */   public void setBnetId(String value)
/*    */   {
/* 32 */     this.bnetId = value;
/*    */   }
/*    */ 
/*    */   public String getBnetAccount()
/*    */   {
/* 44 */     return this.bnetAccount;
/*    */   }
/*    */ 
/*    */   public void setBnetAccount(String value)
/*    */   {
/* 56 */     this.bnetAccount = value;
/*    */   }
/*    */ 
/*    */   public String getCustomerName()
/*    */   {
/* 68 */     return this.customerName;
/*    */   }
/*    */ 
/*    */   public void setCustomerName(String value)
/*    */   {
/* 80 */     this.customerName = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.BnetAccountInfoType
 * JD-Core Version:    0.6.0
 */