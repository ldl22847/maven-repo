/*    */ package cn.eshore.bnet.sdk.ap.entity;
/*    */ 
/*    */ public class MemberAttributeInfoType
/*    */ {
/*    */   protected String attributeValue;
/*    */   protected String id;
/*    */ 
/*    */   public String getAttributeValue()
/*    */   {
/* 20 */     return this.attributeValue;
/*    */   }
/*    */ 
/*    */   public void setAttributeValue(String value)
/*    */   {
/* 32 */     this.attributeValue = value;
/*    */   }
/*    */ 
/*    */   public String getId()
/*    */   {
/* 44 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String value)
/*    */   {
/* 56 */     this.id = value;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.MemberAttributeInfoType
 * JD-Core Version:    0.6.0
 */