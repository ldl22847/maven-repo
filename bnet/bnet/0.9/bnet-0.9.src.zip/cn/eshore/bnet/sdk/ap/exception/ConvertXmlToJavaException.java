/*    */ package cn.eshore.bnet.sdk.ap.exception;
/*    */ 
/*    */ public class ConvertXmlToJavaException extends Exception
/*    */ {
/*    */   public ConvertXmlToJavaException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConvertXmlToJavaException(String message, Throwable cause)
/*    */   {
/* 16 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ConvertXmlToJavaException(String message)
/*    */   {
/* 21 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConvertXmlToJavaException(Throwable cause)
/*    */   {
/* 26 */     super(cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.exception.ConvertXmlToJavaException
 * JD-Core Version:    0.6.0
 */