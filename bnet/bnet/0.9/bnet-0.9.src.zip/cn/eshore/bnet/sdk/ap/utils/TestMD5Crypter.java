/*    */ package cn.eshore.bnet.sdk.ap.utils;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import junit.framework.TestCase;
/*    */ 
/*    */ public class TestMD5Crypter extends TestCase
/*    */ {
/*    */   protected void setUp()
/*    */     throws Exception
/*    */   {
/* 13 */     super.setUp();
/*    */   }
/*    */ 
/*    */   protected void tearDown() throws Exception {
/* 17 */     super.tearDown();
/*    */   }
/*    */ 
/*    */   public void test()
/*    */   {
/* 28 */     StringBuffer sb = new StringBuffer();
/*    */ 
/* 31 */     sb.append("10000");
/* 32 */     sb.append("GD140947240");
/* 33 */     sb.append("983535");
/* 34 */     sb.append("admin");
/* 35 */     sb.append("3542148");
/* 36 */     sb.append("2010-05-31 09:00:00");
/* 37 */     sb.append("1234567890ABCDEF");
/*    */ 
/* 40 */     System.out.println(MD5Crypter.MD5Encode(sb.toString()));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.utils.TestMD5Crypter
 * JD-Core Version:    0.6.0
 */