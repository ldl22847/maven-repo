/*     */ package cn.eshore.bnet.sdk.ap.utils;
/*     */ 
/*     */ import cn.eshore.bnet.sdk.ap.exception.ConvertDocToStringException;
/*     */ import java.io.StringWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ public class Utils
/*     */ {
/*  27 */   private static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */   private static final String ENCODING = "encoding";
/*     */   private static final String UTF_8 = "UTF-8";
/*     */ 
/*     */   public static String getTimeStampStr()
/*     */   {
/*  38 */     return df.format(getCurrentDate());
/*     */   }
/*     */ 
/*     */   public static Date getCurrentDate()
/*     */   {
/*  47 */     return new Date();
/*     */   }
/*     */ 
/*     */   public static boolean isNullObject(Object obj)
/*     */   {
/*  57 */     return obj == null;
/*     */   }
/*     */ 
/*     */   public static boolean isNullOrEmptyString(String str)
/*     */   {
/*  67 */     if ((isNullObject(str)) || ("".equals(str))) {
/*  68 */       return true;
/*     */     }
/*  70 */     return str.length() <= 0;
/*     */   }
/*     */ 
/*     */   public static boolean isNullOrEmptyList(List list)
/*     */   {
/*  82 */     return (isNullObject(list)) || (list.size() == 0);
/*     */   }
/*     */ 
/*     */   public static boolean isNullOrEmptyArray(Object[] obj)
/*     */   {
/*  96 */     return (isNullObject(obj)) || (obj.length == 0);
/*     */   }
/*     */ 
/*     */   public static boolean isOneObjInList(List list)
/*     */   {
/* 109 */     return (!isNullOrEmptyList(list)) && (list.size() == 1);
/*     */   }
/*     */ 
/*     */   public static String convertDocToString(Node node)
/*     */     throws ConvertDocToStringException
/*     */   {
/*     */     try
/*     */     {
/* 118 */       StringWriter stringWriter = new StringWriter();
/* 119 */       TransformerFactory factory = TransformerFactory.newInstance();
/* 120 */       Transformer transformer = factory.newTransformer();
/* 121 */       transformer.setOutputProperty("encoding", "UTF-8");
/* 122 */       transformer.transform(new DOMSource(node), new StreamResult(stringWriter));
/* 123 */       return stringWriter.getBuffer().toString();
/*     */     } catch (TransformerConfigurationException e) {
/* 125 */       throw new ConvertDocToStringException(e); } catch (TransformerException e) {
/*     */     }
/* 127 */     throw new ConvertDocToStringException(e);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.utils.Utils
 * JD-Core Version:    0.6.0
 */