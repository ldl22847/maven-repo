/*     */ package cn.eshore.bnet.sdk.ap.entity;
/*     */ 
/*     */ public class QueryOperType
/*     */ {
/*     */   protected String operId;
/*     */   protected String appSystemId;
/*     */   protected String timeStamp;
/*     */   protected String hashcode;
/*     */ 
/*     */   public String getOperId()
/*     */   {
/*  22 */     return this.operId;
/*     */   }
/*     */ 
/*     */   public void setOperId(String value)
/*     */   {
/*  34 */     this.operId = value;
/*     */   }
/*     */ 
/*     */   public String getAppSystemId()
/*     */   {
/*  46 */     return this.appSystemId;
/*     */   }
/*     */ 
/*     */   public void setAppSystemId(String value)
/*     */   {
/*  58 */     this.appSystemId = value;
/*     */   }
/*     */ 
/*     */   public String getTimeStamp()
/*     */   {
/*  70 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */   public void setTimeStamp(String value)
/*     */   {
/*  82 */     this.timeStamp = value;
/*     */   }
/*     */ 
/*     */   public String getHashcode()
/*     */   {
/*  94 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */   public void setHashcode(String value)
/*     */   {
/* 106 */     this.hashcode = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.entity.QueryOperType
 * JD-Core Version:    0.6.0
 */