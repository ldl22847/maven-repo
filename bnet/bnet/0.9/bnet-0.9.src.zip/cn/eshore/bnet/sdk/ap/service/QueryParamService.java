/*     */ package cn.eshore.bnet.sdk.ap.service;
/*     */ 
/*     */ import cn.eshore.bnet.sdk.ap.entity.ConfirmReqType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.LogAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.QueryCustomerType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.QueryOperType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.ReplyOperType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UseAuthType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UseFinishType;
/*     */ import cn.eshore.bnet.sdk.ap.entity.UserAuthType;
/*     */ 
/*     */ public class QueryParamService
/*     */ {
/*     */   public static String generateQueryString(Object request)
/*     */   {
/*  22 */     if ((request instanceof QueryOperType))
/*  23 */       return dealQueryOper((QueryOperType)request);
/*  24 */     if ((request instanceof ReplyOperType))
/*  25 */       return dealReplyOper((ReplyOperType)request);
/*  26 */     if ((request instanceof QueryCustomerType))
/*  27 */       return dealQueryCustomer((QueryCustomerType)request);
/*  28 */     if ((request instanceof LogAuthType))
/*  29 */       return dealLogAuth((LogAuthType)request);
/*  30 */     if ((request instanceof ConfirmReqType))
/*  31 */       return dealConfirmRequest((ConfirmReqType)request);
/*  32 */     if ((request instanceof UserAuthType))
/*  33 */       return dealUserAuth((UserAuthType)request);
/*  34 */     if ((request instanceof UseAuthType))
/*  35 */       return dealUseAuth((UseAuthType)request);
/*  36 */     if ((request instanceof UseFinishType)) {
/*  37 */       return dealUseFinish((UseFinishType)request);
/*     */     }
/*     */ 
/*  40 */     return null;
/*     */   }
/*     */ 
/*     */   private static String dealQueryOper(QueryOperType queryOper) {
/*  44 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*  46 */     sb.append("servName=gdbnet.queryOper");
/*  47 */     sb.append("&operId=");
/*  48 */     sb.append(queryOper.getOperId());
/*  49 */     sb.append("&appSystemId=");
/*  50 */     sb.append(queryOper.getAppSystemId());
/*  51 */     sb.append("&timeStamp=");
/*  52 */     sb.append(queryOper.getTimeStamp());
/*  53 */     sb.append("&hashcode=");
/*  54 */     sb.append(queryOper.getHashcode());
/*     */ 
/*  56 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static String dealReplyOper(ReplyOperType replyOper) {
/*  60 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*  62 */     sb.append("servName=gdbnet.replyOper");
/*  63 */     sb.append("&operId=");
/*  64 */     sb.append(replyOper.getOperId());
/*  65 */     sb.append("&appSystemId=");
/*  66 */     sb.append(replyOper.getAppSystemId());
/*  67 */     sb.append("&result=");
/*  68 */     sb.append(replyOper.getResult());
/*  69 */     sb.append("&timeStamp=");
/*  70 */     sb.append(replyOper.getTimeStamp());
/*  71 */     sb.append("&hashcode=");
/*  72 */     sb.append(replyOper.getHashcode());
/*     */ 
/*  74 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String dealQueryCustomer(QueryCustomerType queryCustomer)
/*     */   {
/*  79 */     StringBuffer sb = new StringBuffer();
/*     */ 
/*  81 */     sb.append("servName=gdbnet.queryCustomer");
/*  82 */     sb.append("&appSystemId=");
/*  83 */     sb.append(queryCustomer.getAppSystemId());
/*  84 */     sb.append("&bnetId=");
/*  85 */     sb.append(queryCustomer.getBnetId());
/*  86 */     sb.append("&productId=");
/*  87 */     sb.append(queryCustomer.getProductId());
/*  88 */     sb.append("&timeStamp=");
/*  89 */     sb.append(queryCustomer.getTimeStamp());
/*  90 */     sb.append("&hashcode=");
/*  91 */     sb.append(queryCustomer.getHashcode());
/*     */ 
/*  93 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String dealLogAuth(LogAuthType logAuth)
/*     */   {
/*  98 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 100 */     sb.append("servName=gdbnet.logAuth");
/* 101 */     sb.append("&appSystemId=");
/* 102 */     sb.append(logAuth.getAppSystemId());
/* 103 */     sb.append("&bnetAccount=");
/* 104 */     sb.append(logAuth.getBnetAccount());
/* 105 */     sb.append("&userAccount=");
/* 106 */     sb.append(logAuth.getUserAccount());
/* 107 */     sb.append("&password=");
/* 108 */     sb.append(logAuth.getPassword());
/* 109 */     sb.append("&timeStamp=");
/* 110 */     sb.append(logAuth.getTimeStamp());
/* 111 */     sb.append("&hashcode=");
/* 112 */     sb.append(logAuth.getHashcode());
/*     */ 
/* 115 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String dealConfirmRequest(ConfirmReqType confirmReq)
/*     */   {
/* 121 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 123 */     sb.append("servName=gdbnet.confirmReq");
/* 124 */     sb.append("&appSystemId=");
/* 125 */     sb.append(confirmReq.getAppSystemId());
/* 126 */     sb.append("&requestId=");
/* 127 */     sb.append(confirmReq.getRequestId());
/* 128 */     sb.append("&bnetId=");
/* 129 */     sb.append(confirmReq.getBnetId());
/* 130 */     sb.append("&userAccountId=");
/* 131 */     sb.append(confirmReq.getUserAccountId());
/* 132 */     sb.append("&timeStamp=");
/* 133 */     sb.append(confirmReq.getTimeStamp());
/* 134 */     sb.append("&hashcode=");
/* 135 */     sb.append(confirmReq.getHashcode());
/*     */ 
/* 138 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String dealUserAuth(UserAuthType userAuth)
/*     */   {
/* 144 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 146 */     sb.append("servName=gdbnet.userAuth");
/* 147 */     sb.append("&appSystemId=");
/* 148 */     sb.append(userAuth.getAppSystemId());
/* 149 */     sb.append("&userAccountId=");
/* 150 */     sb.append(userAuth.getUserAccountId());
/* 151 */     sb.append("&productId=");
/* 152 */     sb.append(userAuth.getProductId());
/* 153 */     sb.append("&timeStamp=");
/* 154 */     sb.append(userAuth.getTimeStamp());
/* 155 */     sb.append("&hashcode=");
/* 156 */     sb.append(userAuth.getHashcode());
/*     */ 
/* 158 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String dealUseAuth(UseAuthType useAuth)
/*     */   {
/* 165 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 167 */     sb.append("servName=gdbnet.useAuth");
/* 168 */     sb.append("&appSystemId=");
/* 169 */     sb.append(useAuth.getAppSystemId());
/* 170 */     sb.append("&userAccountId=");
/* 171 */     sb.append(useAuth.getUserAccountId());
/* 172 */     sb.append("&productId=");
/* 173 */     sb.append(useAuth.getProductId());
/* 174 */     sb.append("&useSessionId=");
/* 175 */     sb.append(useAuth.getUseSessionId());
/* 176 */     sb.append("&useValue=");
/* 177 */     sb.append(useAuth.getUseValue());
/* 178 */     sb.append("&chargingType=");
/* 179 */     sb.append(useAuth.getChargingType());
/* 180 */     sb.append("&timeStamp=");
/* 181 */     sb.append(useAuth.getTimeStamp());
/* 182 */     sb.append("&hashcode=");
/* 183 */     sb.append(useAuth.getHashcode());
/*     */ 
/* 185 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String dealUseFinish(UseFinishType useFinish)
/*     */   {
/* 192 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 194 */     sb.append("servName=gdbnet.useFinish");
/* 195 */     sb.append("&appSystemId=");
/* 196 */     sb.append(useFinish.getAppSystemId());
/* 197 */     sb.append("&useSessionId=");
/* 198 */     sb.append(useFinish.getUseSessionId());
/* 199 */     sb.append("&useValue=");
/* 200 */     sb.append(useFinish.getUseValue());
/* 201 */     sb.append("&timeStamp=");
/* 202 */     sb.append(useFinish.getTimeStamp());
/* 203 */     sb.append("&hashcode=");
/* 204 */     sb.append(useFinish.getHashcode());
/*     */ 
/* 206 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\bnet\bnet\0.9\bnet-0.9.jar
 * Qualified Name:     cn.eshore.bnet.sdk.ap.service.QueryParamService
 * JD-Core Version:    0.6.0
 */